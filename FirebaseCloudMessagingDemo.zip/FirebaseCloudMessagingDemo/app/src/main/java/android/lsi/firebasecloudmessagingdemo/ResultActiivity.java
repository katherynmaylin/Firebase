package android.lsi.firebasecloudmessagingdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ResultActiivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_actiivity);
    }
}